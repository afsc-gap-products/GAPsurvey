#' @title Public data from FOSS
#' @description This dataset includes zero-filled (presence and absence) observations and catch-per-unit-effort (CPUE) estimates for all identified species at for index stations by the Resource Assessment and Conservation Engineering Division (RACE) Groundfish Assessment Program (GAP) of the Alaska Fisheries Science Center (AFSC). There are no legal restrictions on access to the data. The data from this dataset are shared on the Fisheries One Stop Stop (FOSS) platform (https://www.fisheries.noaa.gov/foss/). The GitHub repository for the scripts that created this code can be found at https://github.com/afsc-gap-products/gap_public_data. For more information about codes used in the tables, please refer to the survey code books (https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual). These data were last updated April 24, 2023.
#' @usage data('public_data')
#' @author Emily Markowitz (emily.markowitz AT noaa.gov)
#' @format A data frame with 905768 observations on the following 35 variables.
#' \describe{
#'   \item{\code{year}}{Area Swept (km). The area the net covered while the net was fishing (kilometers squared), defined as the distance fished times the net width.}
#'   \item{\code{srvy}}{Bottom Temperature (Degrees Celsius). Bottom temperature (tenths of a degree Celsius); NA indicates removed or missing values.}
#'   \item{\code{survey}}{Cruise ID. This is a six-digit number identifying the cruise number of the form: YYYY99 (where YYYY = year of the cruise; 99 = 2-digit number and is sequential; 01 denotes the first cruise that vessel made in this year, 02 is the second, etc.).}
#'   \item{\code{survey_definition_id}}{Date and Time of Haul. The date (MM/DD/YYYY) and time (HH:MM) of the beginning of the haul.}
#'   \item{\code{cruise}}{Depth (m). Bottom depth (tenths of a meter).}
#'   \item{\code{haul}}{Distance Fished (km). Distance the net fished (thousandths of kilometers).}
#'   \item{\code{hauljoin}}{End Latitude (decimal degrees). Latitude (one hundred thousandth of a decimal degree) of the end of the haul.}
#'   \item{\code{stratum}}{End Longitude (decimal degrees). Longitude (one hundred thousandth of a decimal degree) of the end of the haul.}
#'   \item{\code{station}}{Haul ID. This is a unique numeric identifier assigned to each (vessel, cruise, and haul) combination.}
#'   \item{\code{vessel_name}}{Haul Number. This number uniquely identifies a sampling event (haul) within a cruise. It is a sequential number, in chronological order of occurrence.}
#'   \item{\code{vessel_id}}{Haul Performance Code. This denotes what, if any, issues arose during the haul. For more information, review the [code books](https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual).}
#'   \item{\code{date_time}}{ITIS Taxonomic Serial Number. Species code as identified in the Integrated Taxonomic Information System (https://itis.gov/).}
#'   \item{\code{latitude_dd_start}}{Net Height (m). Measured or estimated distance (meters) between footrope and headrope of the trawl.}
#'   \item{\code{longitude_dd_start}}{Net Width (m). Measured or estimated distance (meters) between wingtips of the trawl.}
#'   \item{\code{latitude_dd_end}}{Number CPUE (no/km2). Catch number (in number of organisms) per area (squared kilometers) swept by the net.}
#'   \item{\code{longitude_dd_end}}{Start Latitude (decimal degrees). Latitude (one hundred thousandth of a decimal degree) of the start of the haul.}
#'   \item{\code{species_code}}{Start Longitude (decimal degrees). Longitude (one hundred thousandth of a decimal degree) of the start of the haul.}
#'   \item{\code{itis}}{Station ID. Alpha-numeric designation for the station established in the design of a survey.}
#'   \item{\code{worms}}{Stratum ID. RACE database statistical area for analyzing data. Strata were designed using bathymetry and other geographic and habitat-related elements. The strata are unique to each survey series. Stratum of value 0 indicates experimental tows.}
#'   \item{\code{common_name}}{Surface Temperature (Degrees Celsius). Surface temperature (tenths of a degree Celsius); NA indicates removed or missing values.}
#'   \item{\code{scientific_name}}{Survey ID. This number uniquely identifies a survey. Name and description of survey. The column "survey_id" is associated with the "srvy" and "survey" columns. For a complete list of surveys, review the [code books](https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual).}
#'   \item{\code{taxon_confidence}}{Survey Name. Name and description of survey. The column "survey" is associated with the "srvy" and "survey_id" columns.}
#'   \item{\code{cpue_kgkm2}}{Survey. Abbreviated survey names. The column "srvy" is associated with the "survey" and "survey_id" columns. Northern Bering Sea (NBS), Southeastern Bering Sea (EBS), Bering Sea Slope (BSS), Gulf of Alaska (GOA), Aleutian Islands (AI).}
#'   \item{\code{cpue_nokm2}}{Taxon Code. The species code of the organism associated with the "common_name" and "scientific_name" columns. For a complete species list, review the [code books](https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual).}
#'   \item{\code{weight_kg}}{Taxon Common Name. The common name of the marine organism associated with the "scientific_name" and "species_code" columns. For a complete species list, review the [code books](https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual).}
#'   \item{\code{count}}{Taxon Confidence Rating. Confidence in the ability of the survey team to correctly identify the taxon to the specified level, based solely on identification skill (e.g., not likelihood of a taxon being caught at that station on a location-by-location basis). Quality codes follow: **"High"**: High confidence and consistency. Taxonomy is stable and reliable at this level, and field identification characteristics are well known and reliable. **"Moderate"**: Moderate confidence. Taxonomy may be questionable at this level, or field identification characteristics may be variable and difficult to assess consistently. **"Low"**: Low confidence. Taxonomy is incompletely known, or reliable field identification characteristics are unknown. Documentation: [Species identification confidence in the eastern Bering Sea shelf survey (1982-2008)](http://apps-afsc.fisheries.noaa.gov/Publications/ProcRpt/PR2009-04.pdf), [Species identification confidence in the eastern Bering Sea slope survey (1976-2010)](http://apps-afsc.fisheries.noaa.gov/Publications/ProcRpt/PR2014-05.pdf), and [Species identification confidence in the Gulf of Alaska and Aleutian Islands surveys (1980-2011)](http://apps-afsc.fisheries.noaa.gov/Publications/ProcRpt/PR2014-01.pdf).}
#'   \item{\code{bottom_temperature_c}}{Taxon Count. Total number of individuals caught in haul by taxon, represented in whole numbers.}
#'   \item{\code{surface_temperature_c}}{Taxon Scientific Name. The scientific name of the organism associated with the "common_name" and "species_code" columns. For a complete taxon list, review the [code books](https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual).}
#'   \item{\code{depth_m}}{Taxon Weight (kg). Weight (thousandths of a kilogram) of individuals in a haul by taxon.}
#'   \item{\code{distance_fished_km}}{Tow Duration (decimal hr). This is the elapsed time between start and end of a haul (decimal hours).}
#'   \item{\code{net_width_m}}{Vessel ID. ID number of the vessel used to collect data for that haul. The column "vessel_id" is associated with the "vessel_name" column. Note that it is possible for a vessel to have a new name but the same vessel id number. For a complete list of vessel ID codes, review the [code books](https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual).}
#'   \item{\code{net_height_m}}{Vessel Name. Name of the vessel used to collect data for that haul. The column "vessel_name" is associated with the "vessel_id" column. Note that it is possible for a vessel to have a new name but the same vessel id number. For a complete list of vessel ID codes, review the [code books](https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual).}
#'   \item{\code{area_swept_km2}}{Weight CPUE (kg/km2). Catch weight (kilograms) divided by area (squared kilometers) swept by the net.}
#'   \item{\code{duration_hr}}{World Register of Marine Species Taxonomic Serial Number. Species code as identified in the World Register of Marine Species (WoRMS) (https://www.marinespecies.org/).}
#'   \item{\code{performance}}{Year. Year the survey was conducted in.}#'   }
#' @source https://github.com/afsc-gap-products/gap_public_data
#' @keywords species code data
#' @examples
#' data(public_data)
#' @details DETAILS
'public_data'
