# #' ---
# #' title: GAPsurvey
# #' purpose: assist scientists on the survey collect data
# #' author: Jason Conner (jason.conner AT noaa.gov), Emily Markowitz (emily.markowitz AT noaa.gov), and Liz Dawson (Liz.Dawson AT noaa.gov)
# #' modified by: Emily Markowitz (emily.markowitz AT noaa.gov) and Liz Dawson (Liz.Dawson AT noaa.gov)
# #' start date: 2018?
# #' modified date: June 2021
# #' ---


# Converts ----------------------------------------------


#' BVDR Conversion to Create BTD data
#'
#' Converts Marport BVDR data (.ted and .tet files from Marport headrope sensor) to .BTD format.  You must first run the BVDR converter program (convert_bvdr.exe) to convert the Marport .bvdr files into .ted and .tet files that can be pulled into R. The BVDR program and instructions can be found in the RACE Survey App.  You will have to create your own .SGT file using the example in the BVDR instruction file with start and end time (be sure to include a carriage return after your (second and) final row of data!), because this is not a file that our current systems creates.  Once you have used the BVDR converter to output the .ted and .tet files you are ready to use the convert_ted_btd() function here!
#' @param VESSEL Optional. Default = NA. The vessel number (e.g., 162 for AK Knight, 94 for Vesteraalen). If NA or not called in the function, a prompt will appear asking for this data.
#' @param CRUISE Optional. Default = NA. The cruise number, which is usually the year + sequential two digit cruise (e.g., 202101). If NA or not called in the function, a prompt will appear asking for this data.
#' @param HAUL Optional. Default = NA. The haul number that you are trying to convert data for (e.g., 3). If NA or not called in the function, a prompt will appear asking for this data.
#' @param MODEL_NUMBER Optional. Default = NA. The model number of the Marport sensor (e.g., 123 or 999, you can put in NA or a dummy number here instead of the actual model number without any negative repercussions).
#' @param VERSION_NUMBER Optional. Default = NA. The version number of the Marport sensor (e.g., 123 or 999, you can put in NA or a dummy number here instead of the actual version number without any negative repercussions).
#' @param SERIAL_NUMBER Optional. Default = NA. The serial number of the Marport sensor (e.g., 123 or 999, you can put in NA or a dummy number here instead of the actual serial number without any negative repercussions).
#' @param path_in Optional. The default is the location on the catch computer ("C:/Program Files/Marport Server/Logs/") but any path can be entered.
#' @param path_out Optional. The default is the local working directory but can be specified with a string.
#' @param filename_add Optional. Default = "new". This string will be added to the name of the outputed file. Here, you can additional information that may make this file helpful to find later.
#' @param quiet Optional logical TRUE/FALSE. Default = FALSE. If FALSE, will print a statement or a pop-up window will let the user know where the file has been saved to.
#'
#' @return .BTH and .BTD files to the path_out directory.
#' @export
#'
#' @examples
#' convert_ted_btd(
#'    VESSEL = 94,
#'    CRUISE = 201901,
#'    HAUL = 3,
#'    MODEL_NUMBER = 123,
#'    VERSION_NUMBER = 456,
#'    SERIAL_NUMBER = 789,
#'    path_in = system.file("exdata/convert_bvdr_btd/", package = "GAPsurvey"),
#'    path_out = getwd(),
#'    filename_add = "newted",
#'    quiet = TRUE)
convert_ted_btd <- function(
    VESSEL = NA,
    CRUISE = NA,
    HAUL = NA,
    MODEL_NUMBER = NA,
    VERSION_NUMBER = NA,
    SERIAL_NUMBER = NA,
    path_in = "C:/Program Files/Marport Server/Logs/",
    path_out = "./",
    filename_add = "new",
    quiet = FALSE){

  format_date <- function(x, ...) {
    tmp <- format(x, ...)
    tmp <- sub("^[0]+", "", tmp)
    tmp <- sub('/0', "/", tmp)
    return(tmp)
  }

  if (is.na(VESSEL)){ VESSEL <- readline("Type vessel code:  ") }
  if (is.na(CRUISE)){ CRUISE <- readline("Type cruise number:  ") }
  if (is.na(HAUL)){ HAUL <- readline("Type haul number:  ") }
  if (is.na(MODEL_NUMBER)){ MODEL_NUMBER <- readline("Type model number:  ") }
  if (is.na(VERSION_NUMBER)){ VERSION_NUMBER <- readline("Type version number:  ") }
  if (is.na(SERIAL_NUMBER)){ SERIAL_NUMBER <- readline("Type serial number of Marport height sensor:  ") }

  # make sure path_in comes in with correct format
  path_in <- fix_path(path_in)
  path_out <- fix_path(path_out)

  HAUL <- as.numeric(HAUL)
  shaul <- numbers0(x = HAUL, number_places = 4)

  file.name.ted <- paste(path_in,
                         CRUISE,"_",VESSEL,"_",shaul,".ted",sep="")
  file.name.tet <- paste(path_in,
                         CRUISE,"_",VESSEL,"_",shaul,".tet",sep="")

  ted.file=utils::read.csv(file.name.ted,header=F)
  tet.file=utils::read.csv(file.name.tet,header=F)
  #ted.file$V4=as.numeric(strptime(ted.file[,4], format = "%m/%d/%Y %H:%M:%S"))
  #tet.file$V4=as.numeric(strptime(tet.file[,4], format = "%m/%d/%Y %H:%M:%S"))
  ted.file$V4=strptime(ted.file[,4], format = "%m/%d/%Y %H:%M:%S")
  tet.file$V4=strptime(tet.file[,4], format = "%m/%d/%Y %H:%M:%S")
  ted.file=ted.file[,c(4,6)]
  tet.file=tet.file[,c(4,6)]
  colnames(ted.file)=c("date","depth")
  colnames(tet.file)=c("date","temp")
  # str(ted.file)
  # str(tet.file)
  merged<-base::merge(ted.file,tet.file,all=T)
  # str(merged)
  # head(merged)

  #which(ted.file[,4] %in% tet.file[,4])

  xx=merged$date
  DATE_TIME <- format(xx, format = "%m/%d/%Y %H:%M:%S")

  DATE_TIME_btd <- format(as.POSIXct(DATE_TIME, format = "%m/%d/%Y %H:%M:%S"),
                          format = "%m/%d/%Y %H:%M:%S")

  DATE_TIME_btd <- format_date(DATE_TIME_btd)
  DATE_TIME <- format(xx, format = "%m/%d/%y %H:%M:%S")

  HOST_TIME=max(DATE_TIME)
  LOGGER_TIME=max(DATE_TIME)
  LOGGING_START=min(DATE_TIME)
  LOGGING_END=max(DATE_TIME)
  TEMPERATURE=merged$temp
  DEPTH=merged$depth
  SAMPLE_PERIOD=3
  NUMBER_CHANNELS=2
  NUMBER_SAMPLES=0
  MODE=2

  # Write BTD file
  DATE_TIME <- DATE_TIME_btd
  new.BTD=cbind(VESSEL,CRUISE,HAUL,SERIAL_NUMBER,DATE_TIME,TEMPERATURE,DEPTH)
  new.BTD[which(is.na(new.BTD))]=""
  new.BTD <- data.frame(new.BTD)

  # Write BTH file
  new.BTH=cbind(VESSEL,CRUISE,HAUL,MODEL_NUMBER,VERSION_NUMBER,SERIAL_NUMBER,
                HOST_TIME,LOGGER_TIME,LOGGING_START,LOGGING_END,
                SAMPLE_PERIOD,NUMBER_CHANNELS,
                NUMBER_SAMPLES,MODE)
  new.BTH <- data.frame(new.BTH)

  new.BTD=new.BTD[new.BTD$DEPTH!="2000",]

  #head(new.BTD)
  #return(head(new.BTD))
  filename <- paste0(path_out, "HAUL",shaul,
                     ifelse(is.na(filename_add) | filename_add == "",
                            "", paste0("_", filename_add)))
  utils::write.csv(x = new.BTD,
                   file = paste0(filename, ".BTD"),
                   quote=F,
                   row.names=F,
                   eol=",\n"
  )

  utils::write.csv(x = new.BTH,
                   file = paste0(filename, ".BTH"),
                   quote=F,
                   row.names=F)

  if(!quiet){
    tcltk::tkmessageBox(title = "Message",
                        message = paste0("Your new ", filename,
                                         " .BTD and .BTH files are saved."),
                        icon = "info", type = "ok")
  }
}



#' Convert CTD data in .cnv form to BTD and BTH
#'
#' Before running this convert_ctd_btd function, you will need to use the CTD laptop to convert the raw CTD data to a .cnv file.
#'
#' To do this,
#' 1. use the SBE Data Processing Program, and in the "Run" menu select "1. Data conversion".
#' 2. Under "Program setup file" select the .psa file (should be DataCnv.psa located in CTD folder), under "Instrument configuration file" select the .xmlcon file for the CTD located in the
#' deployment_xmlcon folder- this is CTD specific, know your CTD's serial number, and under "Input directory" select the .hex file (from the CTD computer) that is specific to the haul that you are missing data.  Click "Start Process".
#' The conversion program will ask you for outputs. At the prompt, Select and Add "Time, Elapsed, seconds", "Depth, salt water, m", "Temperature, ITS-90, deg C", "Pressure, Strain Gauge, db", and "Conductivity, S/m".
#' 3. This .cnv file must include columns for "Time, Elapsed, seconds", "Depth , salt water, m", "Temperature, ITS-90, deg C", "Pressure, Strain Gauge, db", and "Conductivity, S/m".
#' 4. Press "Start Process" button again and a .cnv file should appear in your selected output directory.  The .cnv file can then be used for this convert_ctd_btd() function!
#' 5. Look in your output directory (usually the "Documents" folder, but you can find it using getwd()) for your new .BTD and .BTH files.
#'
#' Note that if there are multiple observations from the CTD per second, that they will be averaged by second (e.g., any observations from seconds 0 to >1.0 will be averaged together).
#'
#' @param VESSEL Optional. Default = NA. The vessel number (e.g., 94). If NA or not called in the function, a prompt will appear asking for this data.
#' @param CRUISE Optional. Default = NA. The cruise number, which is usually the year date (e.g., 201901). If NA or not called in the function, a prompt will appear asking for this data.
#' @param HAUL Optional. Default = NA. The haul number, aka the iterative number of this haul (e.g., 3). If NA or not called in the function, a prompt will appear asking for this data.
#' @param MODEL_NUMBER Optional. Default = NA. The model number of the CTD (e.g., 123 or 999, you can put in NA or a dummy number here instead of the actual model number without any negative repercussions).
#' @param VERSION_NUMBER Optional. Default = NA. The version number of the CTD (e.g., 123 or 999, you can put in NA or a dummy number here instead of the actual model number without any negative repercussions).
#' @param SERIAL_NUMBER Optional. Default = NA. The serial number of the CTD (e.g., 123 or 999, you can put in NA or a dummy number here instead of the actual model number without any negative repercussions).
#' @param path_in Optional. Default = "./., or the local working directory but any path (as a string) may be entered. Can accept a .hex file if SBE Data Processing software is installed and path_xmlcon is specified.
#' @param path_out Optional. The default is the local working directory but may be specified with a string.
#' @param path_xmlcon Optional. Filepath to the CTD configuration file (.xmlcon)
#' @param filename_add Optional. Default = "new". This string will be added to the name of the outputed file. Here, you can additional information that may make this file helpful to find later.
#' @param quiet Optional logical TRUE/FALSE. Default = FALSE. If FALSE, will print a statement or a pop-up window will let the user know where the file has been saved to.
#'
#' @return .BTH and .BTD files to the path_out directory.
#' @export
#'
#' @examples
#' convert_ctd_btd(
#'    VESSEL = 94,
#'    CRUISE = 2001,
#'    HAUL = 4,
#'    MODEL_NUMBER = 123, # for example, also can make up
#'    VERSION_NUMBER = 456, # for example, also can make up
#'    SERIAL_NUMBER = 789, # for example, also can make up
#'    path_in = system.file(paste0("exdata/convert_ctd_btd/",
#'       "SBE19plus_01908103_2021_06_01_94_0004_raw.cnv"),
#'        package = "GAPsurvey"),
#'    path_xmlcon = system.file(paste0("exdata/convert_ctd_btd/",
#'      "19-8102_Deploy2021.xmlcon"),
#'       package = "GAPsurvey"),
#'    path_out = getwd(),
#'    filename_add = "newctd",
#'    quiet = TRUE)
#'
#'
#' convert_ctd_btd(
#'    VESSEL = 94,
#'    CRUISE = 202101,
#'    HAUL = 107,
#'    MODEL_NUMBER = "", # for example, also can make up
#'    VERSION_NUMBER = "", # for example, also can make up
#'    SERIAL_NUMBER = 8105, # for example, also can make up
#'    path_in = system.file(paste0("exdata/convert_ctd_btd/",
#'      "2021_06_13_0003.hex"),
#'       package = "GAPsurvey"),
#'    path_xmlcon = system.file(paste0("exdata/convert_ctd_btd/",
#'      "19-8102_Deploy2021.xmlcon"),
#'       package = "GAPsurvey"),
#'    path_out = getwd(),
#'    filename_add = "newctd",
#'    quiet = TRUE)
#'
#' # Copy system files to working directory for example
#' file.copy(
#'    from = system.file("exdata/convert_ctd_btd/2021_06_13_0003.hex",
#'                       package = "GAPsurvey"),
#'    to = gsub(pattern = system.file("exdata/convert_ctd_btd/",
#'              package = "GAPsurvey"),
#'              replacement = getwd(),
#'              x = system.file("exdata/convert_ctd_btd/2021_06_13_0003.hex",
#'                                      package = "GAPsurvey")))
#'
#' file.copy(
#'    from = system.file("exdata/convert_ctd_btd/19-8102_Deploy2021.xmlcon",
#'                        package = "GAPsurvey"),
#'           to = gsub(pattern = system.file("exdata/convert_ctd_btd/",
#'                     package = "GAPsurvey"),
#'                     replacement = getwd(),
#'                     x = system.file("exdata/convert_ctd_btd/19-8102_Deploy2021.xmlcon",
#'                                     package = "GAPsurvey")))
#'
#' # Run convert_ctd_btd on .hex file and .xmlcon file
#' GAPsurvey::convert_ctd_btd(path_in = "2021_06_13_0003.hex",
#'                    path_xmlcon = "19-8102_Deploy2021.xmlcon")
#' # Convert directly from .hex file by using convert_ctd_btd to run SBE Data Processing.
convert_ctd_btd <- function(
    VESSEL = NA,
    CRUISE = NA,
    HAUL = NA,
    MODEL_NUMBER = NA,
    VERSION_NUMBER = NA,
    SERIAL_NUMBER = NA,
    path_in = NA,
    path_out = "./",
    path_xmlcon = NULL,
    filename_add = "",
    quiet = FALSE){

  format_date <- function(x, ...) {
    tmp <- format(x, ...)
    tmp <- sub("^[0]+", "", tmp)
    tmp <- sub('/0', "/", tmp)
    return(tmp)
  }

  if (is.na(VESSEL)){ VESSEL <- readline("Type vessel code:  ") }
  if (is.na(CRUISE)){ CRUISE <- readline("Type cruise number:  ") }
  if (is.na(HAUL)){ HAUL <- readline("Type haul number:  ") }
  if (is.na(MODEL_NUMBER)){ MODEL_NUMBER <- readline("Type model number:  ") }
  if (is.na(VERSION_NUMBER)){ VERSION_NUMBER <- readline("Type version number:  ") }
  if (is.na(SERIAL_NUMBER)){ SERIAL_NUMBER <- readline("Type serial number of CTD:  ") }

  if (is.na(path_in)) {
    tcltk::tkmessageBox(title = "Message",
                        message = "In next window open the CTD .cnv file",
                        icon = "info", type = "ok")
    file.name <- tcltk::tclvalue(tcltk::tkgetOpenFile())
  } else {
    path_in <- fix_path(path_in)
    file.name <- path_in
  }

  if (grepl(pattern = ".hex", x = path_in)) {

    stopifnot("convert_ctd_btd: Must provide path_xmlcon if path_in is a .hex file." = !is.null(path_xmlcon))
    stopifnot("convert_ctd_btd: Must provide path_xmlcon if path_in is a .hex file." = file.exists(path_xmlcon))

    file.name <- GAPsurvey::convert_ctd_hex(hex_file_path = path_in,
                                             xmlcon_path = path_xmlcon,
                                             bat_file = NULL,
                                             datcnv_file = NULL)
  }

  # make sure path_in comes in with correct
  # options(stringsAsFactors = FALSE) # die, factors, die!
  path_out <- fix_path(path_out)

  HAUL <- as.numeric(HAUL)
  shaul <- numbers0(x = HAUL, number_places = 4)

  data0 <- (readLines(file.name))
  header0<-data0[(which(data0 == "# units = specified")+1):
                   (grep(pattern = "# span 0 =", x = data0)-1)]
  header0 <- lapply(strsplit(x = header0, split = " = "), `[[`, 2)
  header0 <- unlist(lapply(strsplit(x = unlist(header0), split = " "), `[[`, 2))
  header0 <- gsub(pattern = ",", replacement = "", x = header0)
  # header0 <- header0[header0 != ""] # flag column
  headers<-data.frame(bth = c("", "timeS", "depth", "temperature", "pressure",
                              "conductivity", "flag"),
                      ctd = c("", "Time", "Depth", "Temperature", "Pressure",
                              "Conductivity", ""))
  # headers<-headers[headers$ctd %in% header0,]
  headers<-headers[match(x = header0, table = headers$ctd), ]

  data1 <- data0[(which(data0 == "*END*")+1):length(data0)]
  # data1 <- unique(data1)

  # datapasta::df_paste(input_table = data1)

  data1 <- data.frame(matrix(data = unlist(strsplit(data1, "\\s+")),
                             ncol = nrow(headers)+1, byrow = TRUE))
  data1$X1 <- NULL
  names(data1)<-headers$bth
  # names(data1) <- header0


  # names(data1) <- c("timeS", "depth", "temperature", "pressure",
  #                  "conductivity", "flag") # , "salinity"

  data1$second <- floor(x = as.numeric(as.character(data1$timeS)))


  # data1 <- data1 %>%
  #   group_by(data1, second) %>%
  #   summarize(m_depth = mean(depth, na.rm = TRUE),
  #             m_temperature = mean(temperature, na.rm = TRUE),
  #             m_pressure = mean(pressure, na.rm = TRUE),
  #             m_conductivity = mean(conductivity, na.rm = TRUE))

  dat <- data1[,c("depth", "temperature", "pressure", "conductivity", "second")]
  dat <- data.frame(base::sapply(X = dat, as.character))
  dat <- data.frame(base::sapply(X = dat, as.numeric))

  data1 <- stats::aggregate.data.frame(x = dat[, c("depth", "temperature",
                                                   "pressure", "conductivity")],
                                       by = list(timeS = data1$second),
                                       FUN = mean,
                                       na.rm = TRUE
  )


  # data1$timeS <- as.POSIXct(data1$timeS)
  # data0 <- oce::read.ctd(file = file.name)
  # data1<-data.frame(data0@data1)

  xx <- data0[(grepl(x = data0, pattern = "* cast   "))]
  xx <- gsub(pattern = "* cast   ", replacement = "", x = xx)
  xx <- strsplit(x = xx, split = ",")[[1]][1]
  xx <- strsplit(x = xx, split = " samples")[[1]][1]
  xx <- gsub(pattern = "\\*[0-9]+ ", x = xx, replacement = "")
  xx <- as.POSIXlt(xx, format = "%d %b %Y %H:%M:%S")
  data1$timeS <- as.numeric(as.character(data1$timeS))
  DATE_TIME <- format((xx + data1$timeS),
                      format = "%Y-%m-%d %H:%M:%S")
  DATE_TIME_btd <- format(as.POSIXct(DATE_TIME),
                          format = "%m/%d/%Y %H:%M:%S")

  DATE_TIME_btd <- format_date(DATE_TIME_btd)

  # DATE_TIME_btd <- gsub(pattern = "^0",
  #                       replacement = "",
  #                       x = DATE_TIME_btd)
  # DATE_TIME_btd <- gsub(pattern = "^0",
  #                       replacement = "",
  #                       x = DATE_TIME_btd)
  DATE_TIME <- format(as.POSIXct(DATE_TIME),
                      format = "%m/%d/%y %H:%M:%S")

  data1$DATE_TIME <- DATE_TIME
  # xx <- as.POSIXlt(data0@metadata$startTime,
  #                         format = "%Y-%m-%d %H:%M:%S")
  #
  # DATE_TIME = format(xx, format = "%m/%d/%Y %H:%M:%S")
  # DATE_TIME <- data1$DATE_TIME <- format((xx + data1$timeS),
  #                                       format = "%m/%d/%Y %H:%M:%S")

  HOST_TIME=max(data1$DATE_TIME)
  LOGGER_TIME=max(data1$DATE_TIME)
  LOGGING_START=min(data1$DATE_TIME)
  LOGGING_END=max(data1$DATE_TIME)
  TEMPERATURE=data1$temperature
  DEPTH=data1$depth
  SAMPLE_PERIOD=3
  NUMBER_CHANNELS=2
  NUMBER_SAMPLES=0
  MODE=2

  # Write BTD file
  # DATE_TIME <- format(as.POSIXct(DATE_TIME, "%m/%d/%y %H:%M:%S"),
  #                     format = "%m/%e/%Y %H:%M:%S")
  DATE_TIME<-DATE_TIME_btd

  new.BTD=cbind(VESSEL,CRUISE,HAUL,SERIAL_NUMBER,DATE_TIME,TEMPERATURE,DEPTH)
  new.BTD[which(is.na(new.BTD))]=""
  new.BTD <- data.frame(new.BTD)

  # Write BTH file
  new.BTH=cbind(VESSEL,CRUISE,HAUL,MODEL_NUMBER,VERSION_NUMBER,SERIAL_NUMBER,
                HOST_TIME,LOGGER_TIME,LOGGING_START,LOGGING_END,
                SAMPLE_PERIOD,NUMBER_CHANNELS,
                NUMBER_SAMPLES,MODE)
  new.BTH <- data.frame(new.BTH)
  new.BTD=new.BTD[new.BTD$DEPTH!="2000",]

  #head(new.BTD)
  #return(head(new.BTD))
  filename <- paste0(path_out, "HAUL",shaul,
                     ifelse(is.na(filename_add) | filename_add == "",
                            "", paste0("_", filename_add)))
  utils::write.csv(x = new.BTD,
                   file = paste0(filename, ".BTD"),
                   quote=F,
                   row.names=F,
                   eol="\n")
  utils::write.csv(x = new.BTH,
                   file = paste0(filename, ".BTH"),
                   quote=F,
                   row.names=F)

  if(!quiet){
    tcltk::tkmessageBox(title = "Message",
                        message = paste0("Your new ", filename,
                                         " .BTD and .BTH files are saved."),
                        icon = "info", type = "ok")
  }

}



#' Convert CTD .hex file to .cnv using SBE Data Processing
#'
#' Converts SBE19plus V2 CTD hex file to cnv using Sea-Bird Data Processing software. cnv files generated with this function will be properly formatted for conversion to BTD using convert_ctd_btd().
#'
#' @param hex_file_path Path to a single .hex file from the CTD.
#' @param xmlcon_path Path to CTD the config file (.xmlcon) for the CTD that was used to collect data in the .hex file.
#' @param bat_file Optional. Filepath to a batch (.bat) file to be executed in command line to run SBE Data Processing. Default NULL automatically uses the .bat file that is included in GAPsurvey.
#' @param datcnv_file Optional. Filepath to .psa file for the SBE Data Processing Datcnv module. Default NULL automatically uses the .psa file that is included in GAPsurvey.
#' @return Writes decoded CTD data to a cnv file and returns the path to the file as a 1L character vector.
#' @export
#'
#' @examples
#' # Copy system files to working directory for example
#' file.copy(from = system.file("exdata/convert_ctd_btd/2021_06_13_0003.hex",
#' package = "GAPsurvey"),
#' to = gsub(pattern = system.file("exdata/convert_ctd_btd/", package = "GAPsurvey"),
#'           replacement = getwd(),
#'           x = system.file("exdata/convert_ctd_btd/2021_06_13_0003.hex",
#'           package = "GAPsurvey")))
#'
#' file.copy(from = system.file("exdata/convert_ctd_btd/19-8102_Deploy2021.xmlcon",
#'                              package = "GAPsurvey"),
#'           to = gsub(pattern = system.file("exdata/convert_ctd_btd/",
#'                                            package = "GAPsurvey"),
#'                                            replacement = getwd(),
#'                     x = system.file("exdata/convert_ctd_btd/19-8102_Deploy2021.xmlcon",
#'                                     package = "GAPsurvey")))
#'
#' # Run convert_ctd_hex()
#' GAPsurvey::convert_ctd_hex(hex_file_path = "2021_06_13_0003.hex",
#'                             xmlcon_path = "19-8102_Deploy2021.xmlcon",
#'                             bat_file = NULL,
#'                             datcnv_file = NULL)
convert_ctd_hex <- function(hex_file_path,
                            xmlcon_path,
                            bat_file = NULL,
                            datcnv_file = NULL) {

  # Replace double backslashes in filepaths with forward slashes
  hex_file_path <- gsub(pattern = "\\\\", replacement = "/", x = hex_file_path)
  xmlcon_path<- gsub(pattern = "\\\\", replacement = "/", x = xmlcon_path)

  # Handle case where file is in the root directory
  if(dirname(hex_file_path) == ".") {
    hex_file_path <- paste0(getwd(), "/", hex_file_path)
  }

  if(dirname(xmlcon_path) == ".") {
    xmlcon_path <- paste0(getwd(), "/", xmlcon_path)
  }

  if(!file.exists(hex_file_path)) {
    stop("convert_ctd_hex: Specified hex_file_path (", hex_file_path,  ") does not exist. Please replace with a valid path to a .hex file.")
  }

  message("convert_ctd_hex: Attempting to convert ", hex_file_path, " to .cnv")

  out_path <- gsub(pattern = ".hex", replacement = "_raw.cnv", x = hex_file_path)

  # Specify paths to .bat and .psa files for SBE data processing
  if(is.null(bat_file)) {
    bat_file <- system.file("exdata/convert_ctd_btd/atsea_getdata.bat", package = "GAPsurvey")
  }

  if(is.null(datcnv_file)) {
    datcnv_file <- system.file("exdata/convert_ctd_btd/DatCnv.psa", package = "GAPsurvey")
  }

  # Run SBE data processing
  system(command = paste0("sbebatch ",
                          bat_file, " ",
                          hex_file_path, " ",
                          datcnv_file, " ",
                          xmlcon_path, " ",
                          sub("/[^/]+$", "", hex_file_path)
  ))

  if(file.exists(out_path)) {
    message("convert_ctd_hex: .cnv file created at ", out_path, ".")
  } else {
    stop("convert_ctd_hex: Failed to convert .hex to .cnv.")
  }

  return(out_path)
}


#' Recover position data from Globe .log file
#'
#' In the event that the MARPORT server GPS fails or is incomplete, "convert_log_gps()" converts GLOBE LOG files into a format that can be uploaded into WHEELHOUSE.
#' To get a .log file that is usable in this function,
#' 1) Go the C:\ globe\ logs\ 2018\ directory and choose GLG file with proper date
#' 2) Use GLOBE Files>Logs> to convert .GLG (binary) to a .LOG (.csv) file
#' 3) convert_log_gps()will prompt you for Vessel code, Cruise no., Haul no. and Date
#' 4) The final prompt will ask for the location of the GLOBE LOG file
#' 5) convert_log_gps()will create csv file in the R directory with filename "new.gps"
#' 6) Rename "new.gps" to HAULXXXX.GPS where XXXX is the haul number
#' 7) Upload HAULXXXX.GPS into WHEELHOUSE
#' 8) NOTE: The raw GLOBE log data are in GMT time (-8 hrs or 4PM AKDT prior day to 4PM current day. Hence if haul with missing GPS spans the 4PM hour (e.g.,3:45-4:30 PM),YOU WILL HAVE TO CONVERT TWO GLG files (current day and next day)and run convert_log_gps()twice & manually combine the two GPS files
#' 9) ALSO NOTE: You may have to shut down GLOBE or wait until after 4pm on following day before all the incoming NMEA data are written to the GLG file.
#'
#' Now that you have a .log file, you can RUN the function by putting your cursor on the "convert_log_gps()" line below & press CTRL+R.
#'
#' @param VESSEL Optional. Default = NA. The vessel number (e.g., 94). If NA or not called in the function, a prompt will appear asking for this data.
#' @param CRUISE Optional. Default = NA. The cruise number, which is usually the year date (e.g., 201901). If NA or not called in the function, a prompt will appear asking for this data.
#' @param HAUL Optional. Default = NA. The haul number, aka the iterative number of this haul (e.g., 3). If NA or not called in the function, a prompt will appear asking for this data.
#' @param DATE Optional. Default = NA. The date in MM/DD/YYYY format (e.g., "06/02/2019"). If NA or not called in the function, a prompt will appear asking for this data.
#' @param path_in Optional. Default = "./., or the local working directory but any path (as a string) may be entered.
#' @param path_out Optional. The default is the local working directory but may be specified with a string.
#' @param filename_add Optional. Default = "new". This string will be added to the name of the outputted file. Here, you can additional information that may make this file helpful to find later.
#' @param quiet Optional logical TRUE/FALSE. Default = FALSE. If FALSE, will print a statement or a pop-up window will let the user know where the file has been saved to.
#'
#' @return A .GPS file to the path_out directory.
#' @export
#'
#' @examples
#' convert_log_gps(
#'     VESSEL = 94,
#'     CRUISE = 201901,
#'     HAUL = 3,
#'     DATE = "06/06/2017",
#'     path_in = system.file("exdata/convert_log_gps/06062017.log",
#'         package = "GAPsurvey"),
#'     path_out = getwd(),
#'     filename_add = "newlog",
#'     quiet = TRUE)
#'
#'  convert_log_gps(
#'     VESSEL = 94,
#'     CRUISE = 202101,
#'     HAUL = 37,
#'     DATE = "06/07/2021",
#'     path_in = system.file("exdata/convert_log_gps/Haul0037.log",
#'         package = "GAPsurvey"),
#'     path_out = getwd(),
#'     filename_add = "newlog",
#'     quiet = TRUE)
convert_log_gps <- function(
    VESSEL = NA,
    CRUISE = NA,
    HAUL = NA,
    DATE = NA,
    path_in = NA,
    path_out = "./",
    filename_add = "",
    quiet = FALSE){

  if (is.na(VESSEL)){ VESSEL <- readline("Type vessel code:  ") }
  if (is.na(CRUISE)){ CRUISE <- readline("Type cruise number:  ") }
  if (is.na(HAUL)){ HAUL <- readline("Type haul number:  ") }
  if (is.na(DATE)){ DATE <- readline("Type date of haul (MM/DD/YYYY):  ") }

  if (is.na(path_in)) {
    tcltk::tkmessageBox(title = "Message",
                        message = paste0("In next window, open the file named ", gsub(pattern = "/", replacement = "", x = DATE), ".log."),
                        icon = "info", type = "ok")
    file.name <- tcltk::tclvalue(tcltk::tkgetOpenFile())
  } else {
    path_in <- fix_path(path_in)
    file.name <- path_in
  }

  # make sure path_in comes in with correct format
  path_out <- fix_path(path_out)

  HAUL <- as.numeric(HAUL)
  shaul <- numbers0(x = HAUL, number_places = 4)

  log.file<-utils::read.csv(file.name,header=F, sep=",")

  only.GPRMC<-log.file[log.file$V1=="$GPRMC",]
  # head(only.GPRMC)
  only.GPRMC<-only.GPRMC[,c(2,4,5,6,7)]
  # head(only.GPRMC)
  info<-cbind(VESSEL, CRUISE, HAUL, DATE)
  infoselect<-cbind(info,only.GPRMC)
  colnames(infoselect)<-c("VESSEL","CRUISE","HAUL","DATE","TIME","LAT1","LAT2","LONG1","LONG2")
  # head(infoselect)

  hh=as.numeric(substr(infoselect$"TIME",start=1, stop=2))
  hh=ifelse(hh<8,hh+24,hh)-8
  hh=ifelse(hh<10,paste0(0,hh),as.character(hh))
  mm=substr(infoselect$"TIME",start=3, stop=4)
  ss=substr(infoselect$"TIME",start=5, stop=6)
  DATE_TIME=paste(infoselect$"DATE", paste(hh,mm,ss,sep=":"))

  lat1=as.numeric(as.character(infoselect$LAT1))
  LAT=ifelse(infoselect$"LAT2"=="N",lat1,-lat1)
  LAT <- formatC(x = LAT, digits = 4, format = "f")

  long1=as.numeric(as.character(infoselect$LONG1))
  LONG=ifelse(infoselect$"LONG2"=="E",long1,-long1)
  LONG <- formatC(x = LONG, digits = 4, format = "f")

  new_gps <- cbind.data.frame(VESSEL, CRUISE, HAUL, DATE_TIME, LAT, LONG)


  filename <- paste0(path_out, "HAUL",shaul,
                     ifelse(is.na(filename_add) | filename_add == "",
                            "", paste0("_", filename_add)),
                     ".gps")

  new_gps1<-new_gps
  names(new_gps1) <- NULL
  new_gps1 <- as.matrix(new_gps1)

  utils::write.table(x = new_gps1,
                     file = filename,
                     quote=FALSE,
                     sep = ",",
                     row.names=FALSE,
                     col.names = FALSE,
                     eol="\n")

  if (!quiet) {
    tcltk::tkmessageBox(title = "Message",
                        message = paste0("Your new .gps files are saved to ", filename),
                        icon = "info", type = "ok")
  }

  message(paste0("Your new .gps files are saved to ", filename))

}



#' Convert .bvdr files to .marp files
#' @description
#' If you mistakenly delete the marport data for a haul, you can retrieve that data through this converter.
#' Before using this script,
#' 1. Open the .bvdr file in Notepad ++ or a similar text editor.
#' 2. Find the uninterpretable character symbol. Often, depending on the editor, this will look like a box or the highlighted letters "SUB". Find and delete (via replace) these characters for the whole document. An error will appear and only part of the file will be read (stopping at the line before where this unsupported symbol is) if you do not edit the data ahead of time.
#' 3. Save the .bvdr file with these changes and use the link to that file below for path_bvdr
#' For an example of what a proper .marp file looks like, refer to system.file("exdata/convert_bvdr_marp/HAUL0001.marp", package = "GAPsurvey")
#' @param path_bvdr Character string. The full path of the .bvdr file you want to convert. For example, path_bvdr <- system.file("exdata/convert_bvdr_marp/20220811-00Za.bvdr", package = "GAPsurvey")
#' @param verbose Logical. Default = FALSE. If you would like a readout of what the file looks like in the console, set to TRUE.
#'
#' @export
#' @examples
#' head(convert_bvdr_marp(path_bvdr = system.file("exdata/convert_bvdr_marp/20220811-00Za.bvdr",
#'                                   package = "GAPsurvey"),
#'           verbose = TRUE), 20)
convert_bvdr_marp <- function(path_bvdr,
                       verbose = FALSE) {

  dat <- readLines(con = path_bvdr, skipNul = TRUE)
  dat1 <- strsplit(x = dat, split = "\\$G")
  dat2 <- strsplit(x = dat, split = "\\:::")
  dat3 <- strsplit(x = dat, split = "\\$01TE")
  dat4 <- strsplit(x = dat, split = "\\$01DST")

  for (i in 1:length(dat1)) {
    if (length(dat1[i][[1]])>1) {
      # if (substr(x = dat1[i][[1]][2], start = 1, stop = 1) == "G"){
      dat1[i][[1]][2] <- paste0("$G", dat1[i][[1]][2])
      # }
    }
    if (length(dat2[i][[1]])>1) {
      dat1[i]<-dat2[i]
      dat1[i][[1]][2] <- paste0(":::", dat1[i][[1]][2])
    }
    if (length(dat3[i][[1]])>1) {
      dat1[i]<-dat3[i]
      dat1[i][[1]][2] <- paste0("$01TE", dat1[i][[1]][2])
    }
    if (length(dat4[i][[1]])>1) {
      dat1[i]<-dat4[i]
      dat1[i][[1]][2] <- paste0("$01DST", dat1[i][[1]][2])
    }
  }
  dat <- sapply(X = dat1, "[", 2)
  dat <- dat[!is.na(dat)]
  dat <- dat[!grepl(pattern = "\\$Gf", x = dat)]
  file_name_out <- gsub(pattern = ".bvdr", replacement = ".marp", x = path_bvdr, fixed = TRUE)
  writeLines(text = dat, con = file_name_out)

  if (verbose) {
    return(dat)
  }
}

# Volumentric Tows

#' Volumetric Tow Calculator
#' @description
#' recall on a boat...
#'     bow
#' port   starbord
#'    stern
#' thus heights in the bin should be taken like this:
#'                     ...bow...
#' bow-port (bp)       bow-center (bc)      bow-starbord (bs)
#' center-port (cp)    center-center (cc)   center-starbord (cs)
#' stern-port (sp)     stern-center (sc)    stern-starbord (ss)
#'                     ...stern...
#' @param volume_method Character: "average" (default) or "contour". If "contour", an inverse-distance weighted interpolation will be applied to the heights across the bin and summed to find volume.
#' If "average", the bin heights will be averaged in 4 area quadrants (as done in old documentation) to find volume.
#' @param density_method Character: "estimated" (default) or "observed". For "observed", add a numeric of the observed (calculated by you on deck) density. For "estimated", create a 2 column data.frame with "taxon" and "prop" (proportion) of each fish caught in the survey: "pollock", "pcod", "Atka mackerel", "pop", "nrf", "Giant grenadier", "flatfish", "snow crab"
#' @param bin_dimentions list of 3 items (length of "bow" side of shape, length of "stern" side of shape, and the "height"s between them) or NULL (default).
#' @param area_of_bin A single numeric with the area, or the bin in cm3 or NULL (default). If null, area will be calculated from the bin_dimensions. Will be used instead of bin_dimentions if not NULL.
#' @param heights_in_bin List of 9 items. See example below for structure. 9 hieghts from the bin should be taken from the stern starbord, center starbord, bow starbord, stern center, center center, bow center, stern port, center port, bow port
#' @param density Dataframe or numeric. For density_method = "observed", add a numeric of the observed (calculated by you on deck) density. For density_method = "estimated", create a 2 column data.frame with "taxon" and "prop" (proportion) of each fish caught in the survey: "pollock", "pcod", "Atka mackerel", "pop", "nrf", "Giant grenadier", "flatfish", "snow crab"
#'
#' @importFrom magrittr %>%
#' @export
#'
#' @examples
#' # Example from EBS 2022 Alaska Knight Haul 144 where a large bag (4650 kg)
#' # was weighed by a load cell but volumetric measurements were also taken for
#' # comparison and study.
#'
#' # 9 heights from the bin at each location described below
#' # see notes above for boat layout.
#' heights_in_bin <- list( # in cm
#'  "ss" = 65, # stern starbord
#'  "cs" = 55, # center starbord
#'  "bs" = 43, # bow starbord
#'  "sc" = 51, # stern center
#'  "cc" = 34, # center center
#'  "bc" = 27, # bow center
#'  "sp" = 20, # stern port
#'  "cp" = 29, # center port
#'  "bp" = 31) # bow port
#'
#' # develop a dataframe of the taxon groups below and proportions found from
#' # sample bag (be sure not to include weights of organisms rescued from the bin!)
#'
#' density_prop <- data.frame(taxon = c("pollock", "pcod", "Atka mackerel",
#'                                      "pop", "nrf", "Giant grenadier",
#'                                      "flatfish", "snow crab"),
#'                            prop = c(0.045011, 0.00533, 0,
#'                                     0.8843, 0, 0,
#'                                     0.022022, 0.0000398))
#' # Prefered/easiest
#'
#' calc_volumetric_tow(volume_method = "contour",
#'                              # Using function to develop an IDW
#'                              # contour over the heights for estimating volume.
#'                density_method = "estimated",
#'                              # Determining density proportions to apply to
#'                              # known densities of fish
#'                bin_dimentions = # Dimensions for the Alaska Knight's
#'                                 # trapezoidal bin, measured in cm
#'                                 list("bow" = 420,
#'                                      "stern" = 355,
#'                                      "height" = 315.5),
#'                              # the height is actually 320, but subtract 4.5
#'                              # for width of board in middle
#'                heights_in_bin = heights_in_bin, # measured in cm
#'                density = density_prop)
#'
#' # Using other methods
#' calc_volumetric_tow(volume_method = "average",
#'                        # Averaging the 4 quadrants of the bin to find volume
#'                density_method = "observed",
#'                        # Directly measured density. See documentation in RACE
#'                        # Survey app for more details.
#'                bin_dimentions = 162,
#'                        # Alaska Knight Vessel code - bin_dimensions stored in
#'                        # the function and this vessel code will look them up
#'                heights_in_bin = heights_in_bin, # Measured in cm
#'                density = 775.8343)
#'                        # if you measured the density directly (this happens
#'                        # to be what the proportions above would solve for)
#'
#' # Using other methods
#' calc_volumetric_tow(volume_method = "average",
#'                        # Averaging the 4 quadrants of the bin to find volume
#'                density_method = "observed",
#'                        # Directly measured density. See documentation in
#'                        # RACE Survey app for more details.
#'                area_of_bin = 122256.2,  # calculated area of the bin.
#'                heights_in_bin = heights_in_bin, # Measured in cm
#'                density = 775.8343)
#'                        # if you measured the density directly (this happens
#'                        # to be what the proportions above would solve for)
#'
#' # F/V Vesteraalen Haul 128 EBS 2022
#' calc_volumetric_tow( # volume_method = "average",
#'   bin_dimentions = 94,
#'   heights_in_bin = list( # in cm
#'     "ss" = 50, # stern starbord
#'     "cs" = 63, # center starbord
#'     "bs" = 56, # bow starbord
#'     "sc" = 50, # stern center
#'     "cc" = 60, # center center
#'     "bc" = 61, # bow center
#'     "sp" = 50, # stern port
#'     "cp" = 50, # center port
#'     "bp" = 41), # bow port,
#'  density = data.frame("taxon" = c("pollock", "pcod", "Atka mackerel",
#'     "pop", "nrf", "Giant grenadier", "flatfish", "snow crab"),
#'     "prop" = c(1, 0, 0, 0, 0, 0, 0, 0)))
calc_volumetric_tow <- function(volume_method = "contour",
                           density_method = "estimated",
                           bin_dimentions = NULL,
                           area_of_bin = NULL,
                           heights_in_bin,
                           density = NULL) {

  if (is.null(area_of_bin)) {
  if (methods::is(object = bin_dimentions, class2 = "list")) {
    bin_dimentions <- bin_dimentions
  } else if (bin_dimentions == 162) { # F/V Alaska Knight
    bin_dimentions <- list("bow" = 420,
                           "stern" = 355,
                           # "port" = 310,
                           # "starbord" = 330,
                           "height" = 315.5) # actually 320, but subtract 4.5 for width of board in middle
  } else if (bin_dimentions == 148) { # F/V Ocean Explorer
    # 29.785 m2
    bin_dimentions <- list("bow" = 440,
                           "stern" = 365,
                           "height" = 740) # actually 320, but subtract 4.5 for width of board in middle
  } else if (bin_dimentions == 94) { # F/V Vesteraalen
    # 29.785 m2
    bin_dimentions <- list("bow" = 320,
                           "stern" = 345,
                           "height" = 325) # actually 320, but subtract 4.5 for width of board in middle
  }
}
  # I. Calculate Catch Volume
  # - Dump the catch into a bin, such that the height (depth) of the catch is maximized (e.g., >3 ft deep).
  # - Level the catch.
  # - Draw diagram of bin area to be used (on back of this form).
  # - Measure the horizontal dimensions (Width and Length) of the bin for the bin area using a tape measure. (for irregular bins, e.g., trapezoids, use the average of unequal Widths and/or Lengths).
  # - Measure the bin Height at multiple positions (perimeter and interior) using a meter stick. Average the Height.
  # - Volume of the bin = Width x Length x Height.
  # An accurate way to estimate the volume of the catch is to imagine the bin as four (or more) rectangles with a corner of each meeting in the middle of the bin. Measure the catch height at each of the four corners of each rectangle. For a bin with four rectangles this is a minimum of 9 catch height estimates (six rectangles is minimum of 12 height measurements). Average the heights from each of the four corners and multiply times the width and length for each of the rectangles to get the volume.

  if (volume_method == "average") {

    if (is.null(area_of_bin)) {

      area_of_bin <- ((bin_dimentions$bow+bin_dimentions$stern)/2)*bin_dimentions$height
    }

    q1 <- (heights_in_bin$bp + heights_in_bin$bc + heights_in_bin$cp + heights_in_bin$cc)/4
    q2 <- (heights_in_bin$cp + heights_in_bin$cc + heights_in_bin$sp + heights_in_bin$cs)/4
    q3 <- (heights_in_bin$bc + heights_in_bin$cc + heights_in_bin$bs + heights_in_bin$sc)/4
    q4 <- (heights_in_bin$cc+ heights_in_bin$sc + heights_in_bin$sc + heights_in_bin$ss)/4

    volume_of_bin <- ( (q1*(area_of_bin/4)) + (q2*(area_of_bin/4)) +
                         (q3*(area_of_bin/4)) + (q4*(area_of_bin/4)) ) * 1e-6

  } else if (volume_method == "contour") {

    bow_stern_diff <- round((bin_dimentions$bow - bin_dimentions$stern)/2, digits = 2)

    df <- heights_in_bin1 <- data.frame("x" = c(bin_dimentions$stern+bow_stern_diff, round(bin_dimentions$stern+(bow_stern_diff/2)), bin_dimentions$bow,
                                                round(bin_dimentions$bow/2), round(bin_dimentions$bow/2), round(bin_dimentions$bow/2),
                                                bow_stern_diff, round(bow_stern_diff/2), 1),
                                        "y" = c(bin_dimentions$h, round(bin_dimentions$h/2), 1,
                                                bin_dimentions$h, round(bin_dimentions$h/2), 1,
                                                bin_dimentions$h, round(bin_dimentions$h/2), 1),
                                        "vals" = (unlist(heights_in_bin)))

    idw.nmax = 4
    grid.cell <- c(10,10)

    bin_polygon <- df
    bin_polygon <- bin_polygon[!grepl(pattern = "m", x = rownames(bin_polygon)),]
    bin_polygon <- bin_polygon[!grepl(pattern = "c", x = rownames(bin_polygon)),]
    bin_polygon <- bin_polygon %>%
      dplyr::arrange(x) %>%
      dplyr::mutate(group = 1) %>%
      sf::st_as_sf(coords = c("x", "y")) %>%
      dplyr::group_by(group) %>%
      dplyr::summarise(geometry = sf::st_combine(geometry)) %>%
      sf::st_cast("POLYGON") #%>%
    # plot()

    x <- df
    colnames(x) <- c("LONGITUDE", "LATITUDE", "CPUE_KGHA")
    x <- sf::st_as_sf(x,
                      coords = c(x = "LONGITUDE", y = "LATITUDE"))

    extrap.box <- sf::st_bbox(x)

    idw_fit <- gstat::gstat(formula = CPUE_KGHA ~ 1, locations = x,
                            nmax = idw.nmax)

    stn.predict <- stats::predict(idw_fit, x)

    sp_extrap.raster <- raster::raster(xmn = extrap.box["xmin"],
                                       xmx = extrap.box["xmax"],
                                       ymn = extrap.box["ymin"],
                                       ymx = extrap.box["ymax"],
                                       ncol = (extrap.box["xmax"] - extrap.box["xmin"])/grid.cell[1],
                                       nrow = (extrap.box["ymax"] - extrap.box["ymin"])/grid.cell[2])

    extrap.grid <- stats::predict(idw_fit, methods::as(sp_extrap.raster, "SpatialPoints")) %>%
      sf::st_as_sf() %>%
      stars::st_rasterize()

    extrap.grid.crop <-  sf::st_crop(x = extrap.grid, y = bin_polygon)

    volume_of_bin <- sum(extrap.grid.crop$var1.pred, na.rm = TRUE) * 1e-6 *
      grid.cell[1] * grid.cell[2]

    # ggplot() +
    #   # stars::geom_stars(data = extrap.grid)  +
    #   stars::geom_stars(data = extrap.grid.crop) +
    #   geom_sf(data = bin_polygon, fill = NA)

  }

  # II. Calculate Catch Density

  if (density_method == "estimated") {
    # - Determine the predominant species in the catch, and use following table below to apply a density estimate.

    if (methods::is(object = density, class2 = "data.frame")) {
    # Density (kg/m3)
    density_est <- data.frame(taxon = c("pollock", "pcod", "Atka mackerel",
                                        "pop", "nrf", "Giant grenadier",
                                        "flatfish", "snow crab"),
                              dens = c(950, 900, 900,
                                       800, 840, 980,
                                       945, 654))

    # - If the catch consists of a mix of several of the above species, use the proportion of each species to
    # calculate density, e.g., 60% POP and 40% pollock: (0.6 x 800) + (0.4 x 950) = 860.
    dens <- dplyr::left_join(density %>%
                               dplyr::mutate(taxon = tolower(taxon)),
                             density_est %>%
                               dplyr::mutate(taxon = tolower(taxon)))
    dens$density <- dens$dens * dens$prop

    density_of_bin <- sum(dens$density)
    }

  } else if (density_method == "observed") {

    # Method 2:
    #   -Measure the density directly. If the catch does not fit easily into one of the above single species or species
    # mixes (e.g., sponge tow), measure the density by filling a deep container of known volume with a random
    # portion of the catch, then weigh that subsample. Density = Weight / Volume = kg/m3.
    # The chemical tote, for example, is a good deep container that allows for an accurate measurement of volume.
    # To get the weight, weigh the tote with the catch (using sling & load-cell), discard the catch (or dump it on the
    # sorting table as part of your normal catch subsample), then weigh the empty tote and subtract that weight.
    # ***Remember to measure your main bin volume first before removing a subsample***

    if (methods::is(object = density, class2 = "numeric") & length(density) == 1) {
      density_of_bin <- density
    }

  }
  # III. Total Catch Weight (kg) = Density x Volume
  # Helpful suggestion: For larger catches, dump only a portion of the catch into the bin for the volumetric estimate, then weigh
  # the remaining portion of the catch still in the trawl net with the crane/load-cell (subtracting the weight of the net). Total
  # Catch weight is then the addition of the remaining net catch weight + bin-volume-estimated weight. The catch subsample
  # can be taken from either portion, but the catch composition needs to be random throughout.

  weight_of_bin <- # kg
    density_of_bin * # m3
    volume_of_bin # kg/m3

  return(weight_of_bin)

}


# Estimate Net Spread ----------------------------------------------------------

#' Calculate Net Spread for tows missing net width using a glm.
#'
#' The Marport Deep Sea Technologies Inc. net mensuration system was used during the deployment of each tow to record net spread and net height. Net width was measured as the horizontal distance between two sensors attached immediately forward of the junction of the upper breastline and the dandyline, and net height was measured from the headrope center to the seafloor. A custom-made AFSC bottom contact sensor (accelerometer) attached to the center of the footrope was used to determine tow duration based on footrope contact with the seafloor. Mean calc_net_spread values for estimating area swept for the tow duration were calculated according to the methods described by Lauth and Kotwicki (2014).
#'
#' In race_data, this will manifest as...
#' net_mensuration_code = Net Mensuration Method
#' 0* Unidentified method. Will make racebase.haul$net_mesured = "N".
#' 1 Scanmar net mensuration - don't use, historical
#' 2 NetMind net mensuration - don't use, historical
#' 3 Furuno net mensuration - don't use, historical
#' 4* Estimated from other hauls - when missing net spread, or spread and hieght. Will make racebase.haul$net_mesured = "N". Estimated using GLM
#' 5* Estimated from warp angle - hopefully, will not come up and shouldn't be used
#' 6 Marport net mensuration - shouldn't be there, indicates raw data
#' 7* Marport with sequential outlier rejection, smoothed mean, and adjusted for MKII offset (see AFSC Proc. Report Lauth & Kotwicki 2014). Will make racebase.haul$net_mesured = "Y".
#'
#' @param dat data.frame. This can be data from GIDES or race_data.hauls, including these columns: WIRE_OUT, NET_HEIGHT, NET_SPREAD
#'
#' @export
#' @return a list of equations
#'
#' @examples
#' # Here is an example using 202101 Alaska Night Data from race_data.hauls:
#' path <- system.file("exdata/calc_net_spread/VESTY202101_RACE_DATA.HAULS.csv",
#'                     package = "GAPsurvey")
#' dat <- read.csv(file=path, header=TRUE, sep=",", stringsAsFactors = FALSE)
#' dat <- dat[dat$PERFORMANCE >= 0 & dat$HAUL_TYPE == 3,]
#' dat[dat$NET_SPREAD_METHOD != 7, "NET_SPREAD"] <- NA # a normal net width
#' dat[dat$NET_HEIGHT_METHOD != 6, "NET_HEIGHT"] <- NA # a normal net height
#' calc_net_spread(dat)
calc_net_spread <- function(dat) {

  dat0 <- dat[,names(dat) %in%
                c("HAUL", "NET_SPREAD",	"NET_HEIGHT",	"WIRE_OUT")]
  dat0$NET_SPREAD_METHODS <- 7 # No Issues
  dat0$NET_HEIGHT_METHOD <- 6 # No Issues
  dat0$WIRE_OUT_METHODS <- 5 # No Issues

  out <- data.frame("method_col" = c(),
                    "method_code" = c(),
                    "n" = c(),
                    "desc" = c())
  # 7: NET_SPREAD_METHOD Marport with sequential outlier rejection, smoothed mean, and adjusted for MKII offset (see AFSC Proc. Report Lauth & Kotwicki 2014). Will make racebase.haul$net_mesured = "Y".
  # if (nrow(dat0[complete.cases(dat0), ])>0) {
  #   n7 <- nrow(dat0[complete.cases(dat0), ])

  if (sum(!is.na(dat0$NET_SPREAD), na.rm = TRUE)>0) {
    n7 <- sum(!is.na(dat0$NET_SPREAD), na.rm = TRUE)
    out <- rbind.data.frame(out,
                            data.frame("method_col" = "NET_SPREAD_METHOD",
                                       "method_code" = 7,
                                       "n" = n7,
                                       "desc" = paste0(
                                         "There were ",
                                         n7,
                                         " hauls successfully completed where the Marport sensor properly caclulated net mensuration using sequential outlier rejection, smoothed mean, and MKII offset adjustments (see AFSC Proc. Report Lauth & Kotwicki 2014).")
                            ))
  }

  # When NET_HEIGHT_METHOD != 6 (aka NA)
  # TOLEDO: Will not work if there are no other tows with the same wire out!
  if (nrow(dat0[!is.na(dat0$NET_HEIGHT), ]) != nrow(dat0)) {
    scope_where_height_missing <- dat0$WIRE_OUT[is.na(dat0$NET_HEIGHT)]
    # out$tows_without_height <- length(scope_where_height_missing)
    dat0$NET_HEIGHT_METHOD[which(is.na(dat0$NET_HEIGHT))] <- 4
    for (i in 1:length(unique(scope_where_height_missing))) {
      dat0$NET_HEIGHT[which(is.na(dat0$NET_HEIGHT) &
                              dat0$WIRE_OUT == unique(scope_where_height_missing)[i])] <-
        mean(dat0$NET_HEIGHT[dat0$WIRE_OUT == unique(scope_where_height_missing)[i]], na.rm = TRUE)
    }

    out <- rbind.data.frame(out,
                            data.frame("method_col" = "NET_HEIGHT_METHOD",
                                       "method_code" = 4,
                                       "n" = length(scope_where_height_missing),
                                       "desc" = paste0(
                                         "There were ",
                                         length(scope_where_height_missing),
                                         " missing net height values estimated by averaging the net height of tows with the same wire out scope.")
                            ))

  }

  # 4* NET_SPREAD_METHOD Estimated from other hauls - when missing net spread, or spread and height Will make racebase.haul$net_mesured = "N". Estimated using GLM
  glm_param <- ""
  if (nrow(dat0[!is.na(dat0$NET_SPREAD), ]) != nrow(dat0)) {

    # Find the best model
    dat1 <- dat0[!is.na(dat0$NET_SPREAD),]
    dat1$INVSCOPE <- 1/dat1$WIRE_OUT
    glm1 = stats::glm(NET_SPREAD  ~ INVSCOPE + NET_HEIGHT + NET_HEIGHT*INVSCOPE,
                      data=c(dat1), family="gaussian")
    glm2 = stats::glm(NET_SPREAD  ~ INVSCOPE + NET_HEIGHT,
                      data=c(dat1), family="gaussian")
    glm3 = stats::glm(NET_SPREAD  ~ INVSCOPE + NET_HEIGHT*INVSCOPE,
                      data=c(dat1), family="gaussian")
    glm4 = stats::glm(NET_SPREAD  ~ NET_HEIGHT + NET_HEIGHT*INVSCOPE,
                      data=c(dat1), family="gaussian")
    glm5 = stats::glm(NET_SPREAD  ~ INVSCOPE,
                      data=c(dat1), family="gaussian")
    glm6 = stats::glm(NET_SPREAD  ~ NET_HEIGHT,
                      data=c(dat1), family="gaussian")
    glm7 = stats::glm(NET_SPREAD  ~ NET_HEIGHT*INVSCOPE,
                      data=c(dat1), family="gaussian")

    best_model <- data.frame(stats::AIC(glm1, glm2, glm3, glm4, glm5, glm6, glm7))
    best_model<-best_model[best_model$AIC <= min(best_model$AIC)+3,] # +3 because basically the same if within 3 of min
    best_model<-best_model[best_model$df <= min(best_model$df),]
    best_model<-best_model[best_model$AIC <= min(best_model$AIC),]

    glm0 <- get(x = rownames(best_model)[1])
    glm0_sum <- summary(glm0)

    # Predict data
    dat0$NET_SPREAD_METHODS[is.na(dat0$NET_SPREAD)] <- 4

    dat1 <- dat0[is.na(dat0$NET_SPREAD),]
    dat1$INVSCOPE <- 1/dat1$WIRE_OUT
    n4 <- nrow(dat1)

    dat0$NET_SPREAD[is.na(dat0$NET_SPREAD)] <-
      stats::predict.glm(object = glm0,
                         newdata = dat1,
                         type="response")

    # Collect coeficents
    glm0_param <- data.frame(glm0_sum$coefficients)
    names(glm0_param) <- c("est0","se","tvalue","prob")
    glm0_param$var <- rownames(glm0_param)
    glm0_param$est <- round(x = glm0_param$est0, digits = 3)
    glm0_param$case <- NA
    for (i in 1:nrow(glm0_param)) {
      if (glm0_param$prob[i] < 0.001) {
        glm0_param$case[i] <- "very signifcant (P < 0.001)"
        # } else if (glm0_param$prob[i] < 0.001) {
        #   glm0_param$case[i] <- "mostly significant (P < 0.001)"
      } else if (glm0_param$prob[i] < 0.01) {
        glm0_param$case[i] <- "significant (P < 0.001)"
      } else if (glm0_param$prob[i] < 0.05) {
        glm0_param$case[i] <- "somewhat significant (P < 0.001)"
      }
    }
    glm0_param$var0 <- tolower(row.names(glm0_param))
    glm0_param$var0 <- gsub(pattern = "(",
                            replacement = "",
                            x = glm0_param$var0,
                            fixed = TRUE)
    glm0_param$var0 <- gsub(pattern = ")",
                            replacement = "",
                            x = glm0_param$var0,
                            fixed = TRUE)
    glm0_param$var0 <- gsub(pattern = ":",
                            replacement = " x ",
                            x = glm0_param$var0,
                            fixed = TRUE)
    glm0_param$var0 <- gsub(pattern = "invscope",
                            replacement = "inversed scope",
                            x = glm0_param$var0,
                            fixed = TRUE)
    glm0_param$var0 <- gsub(pattern = "_",
                            replacement = " ",
                            x = glm0_param$var0,
                            fixed = TRUE)



    str0 <- c()
    if (length(unique(glm0_param$case)) == 1) {
      str0 <- paste0("both predictor variables and their interaction were significant (P < 0.001)")
    } else {
      for (i in 1:length(unique(glm0_param$case))) {
        str0 <- c(str0, paste0(
          text_list(glm0_param$var[glm0_param$case == unique(glm0_param$case)[i]]),
          " were ",
          unique(glm0_param$case)[i]
        ))
      }
      str0 <- text_list(str0)
    }


    fm <- as.character(glm0$formula)
    fm <- paste0(fm[2], " ",
                 fm[1], " ",
                 glm0_param$est[glm0_param$var == "(Intercept)"], " + ",
                 fm[3])

    fm <- gsub(pattern = "NET_SPREAD",
               replacement = "w",
               x = fm, fixed = TRUE)
    if (sum(glm0_param$var == "INVSCOPE:NET_HEIGHT")>0) {
      fm <- gsub(pattern = "NET_HEIGHT * INVSCOPE",
                 replacement = paste0(glm0_param$est[glm0_param$var == "INVSCOPE:NET_HEIGHT"],
                                      " * (h/s)"),
                 x = fm, fixed = TRUE)
    }
    if (sum(glm0_param$var == "NET_HEIGHT")>0) {
      fm <- gsub(pattern = "NET_HEIGHT",
                 replacement = paste0(glm0_param$est[glm0_param$var == "NET_HEIGHT"],
                                      " * h"),
                 x = fm, fixed = TRUE)
    }
    if (sum(glm0_param$var == "INVSCOPE")>0) {
      fm <- gsub(pattern = "INVSCOPE",
                 replacement = paste0(glm0_param$est[glm0_param$var == "INVSCOPE"],
                                      "/s"),
                 x = fm, fixed = TRUE)
    }
    fm <- gsub(pattern = " + -",
               replacement = " - ",
               x = fm, fixed = TRUE)

    out <- rbind.data.frame(out,
                            data.frame("method_col" = "NET_SPREAD_METHOD",
                                       "method_code" = 4,
                                       "n" = n4,
                                       "desc" = paste0(fm,
                                                       ": For ",
                                                       n4,
                                                       " hauls, the net width was estimated using a generalized linear model. The ",
                                                       str0)
                            ))


    # # if the interaction between INVSLOPE and HEIGHT are not significant
    # if ((glm1_sum$coefficients[4,4]>0.05)) {
    #   # Find the best model
    #   glm2 = glm(SPREAD ~ INVSCOPE + HEIGHT,
    #              data=c(dat),family="gaussian")
    #   glm2_sum <- summary(glm2)
    #   glm0<-glm2
    #   eq <- "w ~ 1/s + h: inverse scope and net height were significant (P < 0.001) but not their interaction term"
    # }
    # str <- paste0(str, eq, "
    #
    #               ")
  }

  # 0* Unidentified method. Will make racebase.haul$net_mesured = "N".

  # 5 Estimated from warp angle - hopefully, will not come up and shouldn't be used


  out <- list(#"plot" = plot(dat$NET_SPREAD,1/dat$WIRE_OUT),
    "actions" = out,
    "glm_summary" = glm0_param,
    "dat" = dat0)

  return(out)
}

# Check Past Tows --------------------------------------------------------------

#' Get sunrise and sunset times by day, latitude, and longitude
#'
#' @param chosen_date Date, formatted as YYYY-MM-DD
#' @param latitude Numeric latitude in either decimal degrees or a character latitude in degrees and decimal minutes
#' @param longitude Numeric longitude in either decimal degrees or a character longitude in degrees and decimal minutes
#' @param verbose Logical. Default = FALSE. If you would like a readout of what the file looks like in the console, set to TRUE.
#'
#' @return Time of sunrise and sunset in text. Also shows a pop-up with sunrise and sunset times.
#' @export
#'
#' @examples
#' get_sunrise_sunset(chosen_date = Sys.Date(), latitude = 63, longitude = 170)
get_sunrise_sunset <- function(chosen_date, latitude, longitude, verbose = FALSE) {
  # Are lat/long in degrees and decimal mins? If so, convert to decimal degrees.

  if (!(methods::is(object = chosen_date, class2 = "POSIXct"))) {
    chosen_date <- as.POSIXct(chosen_date)
  }

  ddm <- is.character(latitude) | is.character(longitude)
  if (ddm) {
    if (!grepl(" ", x = latitude) | !grepl(" ", x = longitude)) {
      stop("You have chosen degrees and decimal minutes but have no space in the character string you entered. Please format your lat and/or long as D mm.m OR enter a numeric value for decimal degrees")
    }
    lat_deg <- as.numeric(gsub(" .*$", "", latitude))
    lat_min <- as.numeric(gsub("^\\S+\\s+", "", latitude)) / 60
    latitude <- lat_deg + lat_min

    lon_deg <- as.numeric(gsub(" .*$", "", longitude))
    lon_min <- as.numeric(gsub("^\\S+\\s+", "", longitude)) / 60
    longitude <- lon_deg + lon_min
  }

  sunrise <- maptools::sunriset(
    crds = sp::SpatialPoints(
      matrix(c(longitude, latitude),
             ncol = 2
      ),
      proj4string = sp::CRS("+proj=longlat +datum=WGS84")
    ),
    dateTime = chosen_date,
    direction = "sunrise",
    POSIXct.out = TRUE
  )$time

  sunset <- maptools::sunriset(
    crds = sp::SpatialPoints(
      matrix(c(longitude, latitude),
             ncol = 2
      ),
      proj4string = sp::CRS("+proj=longlat +datum=WGS84")
    ),
    dateTime = chosen_date,
    direction = "sunset",
    POSIXct.out = TRUE
  )$time

  # fix time zone to Dutch/Anchorage (AKST)
  sunrise <- lubridate::with_tz(sunrise, tzone = "US/Alaska")
  sunset <- lubridate::with_tz(sunset, tzone = "US/Alaska")

  message(
    "Sunrise is at ", sunrise, "AKST",
    "\n Sunset is at ", sunset, "AKST"
  )
}




#' Find historical catch data from previous years
#'
#' @param survey (character) A character string of the survey you are interested in reivewing. Options are those from public_data$survey, which are "AI", "GOA", "EBS", "NBS", "BSS".
#' @param species_codes (numeric) A species code number of a species or species you are specifically interested in reviewing data from. If NA/not entered, the function will return data for all species caught in the haul.
#' @param station (character) A character string of the current station name (as a grid cell; e.g., "264-85")
#' @param grid_buffer (numeric) GOA/AI only. The number of cells around the current station where you would like to see catches from. Typically, use grid_buffer = 3.
#' @param years (numeric) the years you want returned in the output. If years = NA, script will default to the last 10 years. If you would like to see all years, simply choose a large range that covers all years of the survey (e.g., 1970:2030)
#'
#' @importFrom magrittr "%>%"
#' @export
#' @return a data.frame of past catches and hauls
#'
#' @examples
#' #' # EBS (or NBS) --------------------------------------------------------------
#'
#' ## for one year and only 1 station for all species --------------------------
#' get_catch_haul_history(
#'      survey = "EBS",
#'      years = 2021,
#'      station = "I-13")
#'
#' ## for default 10 years and only 1 station  for PCOD and walleye pollock ----
#' get_catch_haul_history(
#'      species_codes = c(21720, 21740), # pacific cod and walleye pollock
#'      survey = "EBS",
#'      station = "I-13")
#'
#' # AI (or GOA) ---------------------------------------------------------------
#'
#' ## for two specific years and nearby stations -------------------------------
#' get_catch_haul_history(
#'       survey = "AI",
#'       years = c(2016, 2018),
#'       station = "324-73",
#'       grid_buffer = 3)
#'
#' ## for default 10 years and nearby stations for all species (a typical use-case) ----
#' get_catch_haul_history(
#'      survey = "AI",
#'      years = NA, # default
#'      station = "324-73",
#'      grid_buffer = 3)
#'
#' ## for default 10 years and nearby stations for Bering Flounder (0 results returned!) ---
#' get_catch_haul_history(
#'      survey = "AI",
#'      species_codes = 10140, # Bering flounder which would be VERY unlikely to be found
#'      years = NA, # default
#'      station = "324-73",
#'      grid_buffer = 3)
get_catch_haul_history <- function(
    survey,
    species_codes = NA,
    years = NA,
    station,
    grid_buffer = NA) {

  utils::data("public_data", envir=environment())

  public_data0 <-
    GAPsurvey::public_data[GAPsurvey::public_data$srvy == survey,
                c("year", "srvy", "haul", "stratum", "station",
                  "vessel_name", "vessel_id", "date_time", "latitude_dd_start", "longitude_dd_start",
                  "species_code", "common_name", "scientific_name", "taxon_confidence",
                  "cpue_kgha", "cpue_noha", "weight_kg", "count",
                  "bottom_temperature_c", "surface_temperature_c", "depth_m",
                  "distance_fished_km", "net_width_m", "net_height_m", "area_swept_ha", "duration_hr")]

  if (!is.na(years[1])) {
    public_data0 <- public_data0[public_data0$year %in% years,]
  } else { # default: show 10 years average
    public_data0 <- public_data0[public_data0$year %in% sort(unique(public_data0$year),
                                                             decreasing = TRUE)[1:10], ]
  }

  if (is.na(grid_buffer)) {
    public_data0 <- public_data0[public_data0$station == station,]
  }

  public_data1 <- public_data0 # so we can calculate the total_weight_kg

  if (!is.na(species_codes[1])) {
    public_data0 <- public_data0[public_data0$species_code %in% species_codes,]
  }

  # if (survey == "EBS" | survey == "NBS") {
  #
  #   lat <- mean(unique(public_data0$latitude_dd_start[public_data0$station == station]), na.rm = TRUE)
  #   lon <- mean(unique(public_data0$longitude_dd_start[public_data0$station == station]), na.rm = TRUE)
  #
  #   possible_stations <-
  #   unique(public_data0$station[
  #     (public_data0$latitude_dd_start >= lat-deg_range &
  #        public_data0$latitude_dd_start <= lat+deg_range) &
  #       (public_data0$longitude_dd_start >= lon-deg_range &
  #          public_data0$longitude_dd_start <= lon+deg_range)])
  #
  # }

  if (nrow(public_data0) == 0) {
    out <- "Your quiery returned 0 results."
  } else {

    if (survey == "AI" | survey == "GOA") {

      y <- as.numeric(strsplit(x = station, split = "-", fixed = TRUE)[[1]])

      if (grid_buffer != 3) {
        stop("the grid cell buffer is fixed at 3 for now.")
      }
      possible_stations <- expand.grid(
        data.frame(
          rbind(
            y + grid_buffer,
            y + grid_buffer - 1,
            y + grid_buffer - 2,
            y,
            y - grid_buffer,
            y - grid_buffer - 1,
            y - grid_buffer - 2
          )
        )
      )

      possible_stations$station <- paste(possible_stations$X1,
                                         possible_stations$X2,
                                         sep = "-")
      possible_stations <- possible_stations$station

      xx <- public_data0[public_data0$station %in% possible_stations,]
      public_data1 <- public_data1[public_data1$station %in% possible_stations,] # for calc total weight of haul

      catch <- stats::aggregate(xx[, c("count", "weight_kg", "cpue_kgha", "cpue_noha")],
                                by = list(
                                  haul = factor(xx$haul),
                                  year = factor(xx$year),
                                  scientific_name = factor(xx$scientific_name),
                                  common_name = factor(xx$common_name),
                                  station = factor(xx$station)),
                                sum)

      haul <- unique(xx[,c("year", "haul", "station", "stratum",
                           "vessel_name", "date_time", "latitude_dd_start", "longitude_dd_start",
                           "bottom_temperature_c", "surface_temperature_c", "depth_m",
                           "distance_fished_km", "net_width_m", "net_height_m", "area_swept_ha", "duration_hr")])

    } else if (survey == "EBS" | survey == "NBS") {
      catch <- public_data0[,c("year", "station", "scientific_name", "common_name",
                               "count", "weight_kg", "cpue_kgha", "cpue_noha")]
      haul <- unique(public_data0[,c("year", "haul", "station", "stratum",
                                     "vessel_name", "date_time", "latitude_dd_start", "longitude_dd_start",
                                     "bottom_temperature_c", "surface_temperature_c", "depth_m",
                                     "distance_fished_km", "net_width_m", "net_height_m",
                                     "area_swept_ha", "duration_hr")])
    }

    # add total weight to haul table
    haul <- base::merge(
      x = haul,
      y = stats::aggregate(public_data1[, c("weight_kg")],
                           by = list(
                             year = factor(public_data1$year),
                             station = factor(public_data1$station)),
                           sum, na.rm = TRUE),
      by = c("year", "station"))
    names(haul)[ncol(haul)] <- "total_weight_kg"
    haul[,ncol(haul)] <- round(x = haul[,ncol(haul)], digits = 2)


    catch$year <- as.numeric(as.character(catch$year))
    catch <- catch[order(-catch$year, -catch$weight_kg), ]
    rownames(catch)<-1:nrow(catch)
    catch$count[catch$count == 0] <- NA

    cc <- split(catch, catch$year)
    cc <- lapply(cc, function(df) { (df[order(-df$year, -df$weight_kg), names(catch) != c("year")]) })

    if (length(unique(catch$year))>1 | length(unique(catch$station))>1) {

      temp <- data.frame(table(catch[,c("scientific_name")]))
      if (sum(names(temp) == "Var1") == 1) {
        names(temp)[names(temp) == "Var1"] <- "scientific_name"
      }
      catch_means <- base::merge(
        x = stats::aggregate(catch[, c("count", "weight_kg", "cpue_kgha", "cpue_noha")],
                             by = list(
                               scientific_name = factor(catch$scientific_name),
                               common_name = factor(catch$common_name),
                               station = factor(catch$station)),
                             mean, na.rm = TRUE),
        y = temp,
        by = "scientific_name"#,
        # by.x = "scientific_name",
        # by.y = "Var1"
        )
      if (nrow(catch_means) == 0) {
        catch_means <- "There was no data available for these function parameters"
      } else {
        catch_means <- catch_means[order(-catch_means$cpue_kgha),]
        catch_means$count <- round(x = catch_means$count, digits = 1)
        catch_means$weight_kg <- round(x = catch_means$weight_kg, digits = 2)
        catch_means$cpue_kgha <- round(x = catch_means$cpue_kgha, digits = 2)
        catch_means$cpue_noha <- round(x = catch_means$cpue_noha, digits = 2)
        rownames(catch_means) <- 1:nrow(catch_means)

      }

    } else {
      catch_means <- "A summary of catch data would not be helpful with these function parameters"
    }

    catch$weight_kg <- round(x = catch$weight_kg, digits = 2)
    catch$cpue_kgha <- round(x = catch$cpue_kgha, digits = 2)
    catch$cpue_noha <- round(x = catch$cpue_noha, digits = 2)

    out <- list("catch" = cc,
                "catch_means" = catch_means,
                "haul" = haul)
  }

  return(out)
}


# Helper Functions ------------------------------------------------------------------------

#' Takes a string of words and combines them into a sentance that lists them.
#'
#' This function alows you to take a string of words and combine them into a sentance list. For example, 'apples', 'oranges', 'pears' would become 'apples, oranges, and pears'. This function uses oxford commas.
#' @param x Character strings you want in your string.
#' @param oxford T/F: would you like to use an oxford comma? Default = TRUE
#' @param sep string. default = "," but ";" might be what you need!
#' @keywords strings
#' @export
#' @examples text_list(c(1,2,"hello",4,"world",6))
text_list<-function(x, oxford = TRUE, sep = ",") {
  x<-x[which(x!="")]
  # x<-x[which(!is.null(x))]
  x<-x[which(!is.na(x))]
  # x<-x[order(x)]
  if (length(x)==2) {
    str1<-paste(x, collapse = " and ")
  } else if (length(x)>2) {
    str1<-paste(x[1:(length(x)-1)], collapse = paste0(sep, " "))
    str1<-paste0(str1,
                 ifelse(oxford == TRUE, sep, ""),
                 " and ", x[length(x)])
  } else {
    str1<-x
  }
  return(str1)
}

#' Make numbers the same length preceeded by 0s
#'
#' @param x a single or vector of values that need to be converted from something like 1 to "001"
#' @param number_places default = NA. If equal to NA, the function will take use the longest length of a value provided in x (example 1). If equal to a number, it will make sure that every number is the same length of number_places (example 2) or larger (if a value of x has more places than number_places(example 3)).
#'
#' @export
#' @return A string of the values in x preceeded by "0"s
#'
#' @examples
#' # example 1
#' numbers0(x = c(1,11,111))
#' # example 2
#' numbers0(x = c(1,11,111), number_places = 4)
#' # example 3
#' numbers0(x = c(1,11,111), number_places = 2)
numbers0 <- function (x, number_places = NA) {
  x<-as.numeric(x)
  xx <- rep_len(x = NA, length.out = length(x))
  if (is.na(number_places)){
    number_places <- max(nchar(x))
  }
  for (i in 1:length(x)) {
    xx[i] <- paste0(ifelse(number_places<nchar(x[i]),
                           "",
                           paste(rep_len(x = 0,
                                         length.out = number_places-nchar(x[i])),
                                 collapse = "")), as.character(x[i]))
  }
  return(xx)
}


#' Make sure file path is complete
#'
#' Function adds '/' or '\\' to the end of directories and recognizes when there are file extentions at the end of strings.
#'
#' @param path A string with the complete path of the directory or file.
#'
#' @export
#' @return A fixed path string.
#'
#' @examples
#' fix_path("sdfg/sdfg/sdfg/dfg.dd")
#' fix_path("sdfg/sdfg/sdfg")
#' fix_path("sdfg/sdfg/sdfg/")
fix_path <- function(path) {
  path0 <- ifelse(
    # Does the string end with a back slash?
    substr(x = path,
           start = nchar(path),
           stop = nchar(path)) %in% c("/", "\\") |
      # or if there is a file extention?
      grepl(pattern = "\\.",
            x = substr(x = path,
                       start = nchar(path)-7,
                       stop = nchar(path))),
    path,
    paste0(path, "/") )

  return(path0)
}

# Data ------------------------------------------------------------------------------------

#' @title PolySpecies Data Set
#' @description polynumbers
#' @usage data(PolySpecies)
#' @author Jason Conner (jason.conner AT noaa.gov)
#' @format A data frame with 172 rows and 4 variables:
#' \describe{
#'   \item{\code{SPECIES_CODE}}{integer Species code}
#'   \item{\code{POLY_SPECIES_CODE}}{integer Poly species code}
#'   \item{\code{SPECIES_NAME}}{character Species scientific latin name}
#'   \item{\code{COMMON_NAME}}{character Species common names}
#'}
#' @details DETAILS
#' @keywords catch data
#' @examples
#' data(PolySpecies)
"PolySpecies"


#' @title species data codes
#' @description RACEBASE Species Codes and Scientific Names Data Set
#' @usage data(species_data)
#' @author Sarah Friedman (sarah.friedman AT noaa.gov)
#' @format A data frame with 172 rows and 4 variables:
#' \describe{
#'   \item{\code{species_code}}{integer Species code}
#'   \item{\code{common_name}}{integer Poly species code}
#'   \item{\code{scientific_name}}{character Species scientific latin name}
#'   \item{\code{scientific_name_old}}{character Species scientific latin name used previously}
#'}
#' @details DETAILS
#' @keywords species scientific code data
#' @examples
#' data(species_data)
"species_data"

#' @title Public data from FOSS
#' @description Public data from FOSS
#' @usage data("public_data")
#' @author Emily Markowitz (emily.markowitz AT noaa.gov)
#' @format A data frame with 878805 observations on the following 33 variables.
#' \describe{
#'   \item{\code{year}}{a numeric vector; Year the survey was conducted in. }
#'   \item{\code{srvy}}{a character vector; Abbreviated survey names. The column “srvy” is associated with the “survey” and “survey_id” columns. Northern Bering Sea (NBS), Southeastern Bering Sea (EBS), Bering Sea Slope (BSS), Gulf of Alaska (GOA), Aleutian Islands (AI). }
#'   \item{\code{survey}}{a character vector; Name and description of survey. The column “survey” is associated with the “srvy” and “survey_id” columns. }
#'   \item{\code{survey_id}}{a numeric vector; This number uniquely identifies a survey. Name and description of survey. The column “survey_id” is associated with the “srvy” and “survey” columns. For a complete list of surveys go to https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual}
#'   \item{\code{cruise}}{a numeric vector; This is a six-digit number identifying the cruise number of the form: YYYY99 (where YYYY = year of the cruise; 99 = 2-digit number and is sequential; 01 denotes the first cruise that vessel made in this year, 02 is the second, etc.)}
#'   \item{\code{haul}}{a numeric vector; This number uniquely identifies a sampling event (haul) within a cruise. It is a sequential number, in chronological order of occurrence.}
#'   \item{\code{stratum}}{a numeric vector; RACE database statistical area for analyzing data. Strata were designed using bathymetry and other geographic and habitat-related elements. The strata are unique to each survey series. Stratum of value 0 indicates experimental tows. }
#'   \item{\code{station}}{a character vector; Alpha-numeric designation for the station established in the design of a survey. }
#'   \item{\code{vessel_name}}{a character vector; Name of the vessel used to collect data for that haul. The column “vessel_name” is associated with the “vessel_id” column. Note that it is possible for a vessel to have a new name but the same vessel id number. For a complete list of vessel ID codes: https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual}
#'   \item{\code{vessel_id}}{a numeric vector; ID number of the vessel used to collect data for that haul. The column “vessel_id” is associated with the “vessel_name” column. Note that it is possible for a vessel to have a new name but the same vessel id number. For a complete list of vessel ID codes: https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual}
#'   \item{\code{date_time}}{a character vector; The date (MM/DD/YYYY) and time (HH:MM) of the beginning of the haul. }
#'   \item{\code{latitude_dd_start}}{a numeric vector; Latitude (one hundred thousandth of a decimal degree) of the start of the haul.}
#'   \item{\code{longitude_dd_start}}{a numeric vector; Longitude (one hundred thousandth of a decimal degree) of the start of the haul.}
#'   \item{\code{latitude_dd_end}}{a numeric vector; Latitude (one hundred thousandth of a decimal degree) of the start of the haul.}
#'   \item{\code{longitude_dd_end}}{a numeric vector; Longitude (one hundred thousandth of a decimal degree) of the start of the haul.}
#'   \item{\code{species_code}}{a numeric vector; The species code of the organism associated with the “common_name” and “scientific_name” columns. For a complete species list go to https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual}
#'   \item{\code{common_name}}{a character vector; The common name of the marine organism associated with the “scientific_name” and “species_code” columns. For a complete species list go to https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual}
#'   \item{\code{scientific_name}}{a character vector; The scientific name of the organism associated with the “common_name” and “species_code” columns. For a complete taxon list go to https://www.fisheries.noaa.gov/resource/document/groundfish-survey-species-code-manual-and-data-codes-manual}
#'   \item{\code{taxon_confidence}}{a character vector; Confidence in the ability of the survey team to correctly identify the taxon to the specified level, based solely on identification skill (e.g., not likelihood of a taxon being caught at that station on a location-by-location basis). Quality codes follow: “High”: High confidence and consistency. Taxonomy is stable and reliable at this level, and field identification characteristics are well known and reliable. “Moderate”: Moderate confidence. Taxonomy may be questionable at this level, or field identification characteristics may be variable and difficult to assess consistently. “Low”: Low confidence. Taxonomy is incompletely known, or reliable field identification characteristics are unknown. Species identification confidence in the eastern Bering Sea shelf survey (1982-2008): http://apps-afsc.fisheries.noaa.gov/Publications/ProcRpt/PR2009-04.pdf Species identification confidence in the eastern Bering Sea slope survey (1976-2010): http://apps-afsc.fisheries.noaa.gov/Publications/ProcRpt/PR2014-05.pdf Species identification confidence in the Gulf of Alaska and Aleutian Islands surveys (1980-2011): http://apps-afsc.fisheries.noaa.gov/Publications/ProcRpt/PR2014-01.pdf}
#'   \item{\code{cpue_kgkm2}}{a numeric vector; Relative Density. Catch weight (kilograms) divided by area (squared kilometers) swept by the net. }
#'   \item{\code{cpue_nokm2}}{a numeric vector; Relative Abundance. Catch number (in number of organisms) per area (squared kilometers) swept by the net. }
#'   \item{\code{weight_kg}}{a numeric vector; Weight (thousandths of a kilogram) of individuals in a haul by taxon. }
#'   \item{\code{count}}{a numeric vector; Total number of individuals caught in haul by taxon, represented in whole numbers. }
#'   \item{\code{bottom_temperature_c}}{a numeric vector; Bottom temperature (tenths of a degree Celsius); NA indicates removed or missing values.}
#'   \item{\code{surface_temperature_c}}{a numeric vector; Surface temperature (tenths of a degree Celsius); NA indicates removed or missing values. }
#'   \item{\code{depth_m}}{a numeric vector; Bottom depth (tenths of a meter).}
#'   \item{\code{distance_fished_km}}{a numeric vector; Distance the net fished (thousandths of kilometers). }
#'   \item{\code{net_width_m}}{a numeric vector; Measured or estimated distance (meters) between wingtips of the trawl.}
#'   \item{\code{net_height_m}}{a numeric vector; Measured or estimated distance (meters) between footrope and headrope of the trawl.}
#'   \item{\code{area_swept_ha}}{a numeric vector; The area the net covered while the net was fishing (hectares), defined as the distance fished times the net width. }
#'   \item{\code{duration_hr}}{a numeric vector; This is the elapsed time between start and end of a haul (decimal hours). }
#'   }
#' @source https://github.com/afsc-gap-products/gap_public_data
#' @keywords species code data
#' @examples
#' data(public_data)
#' @details DETAILS
"public_data"


