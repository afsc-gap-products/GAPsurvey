install.packages("C:/CTD/ctd_computer_software/GAPsurvey_2023.04.01.tar.gz")

GAPsurvey::convert_ctd_btd(path_in = system.file("exdata/convert_ctd_btd/2021_06_13_0003.hex", 
                                                 package = "GAPsurvey"),
                           path_xmlcon = system.file("exdata/convert_ctd_btd/19-8102_Deploy2021.xmlcon", 
                                                     package = "GAPsurvey") )



library(GAPsurvey)


GAPsurvey::convert_ctd_btd(path_in = "C:/CTD/202301_162_L1/SBE19plus_01908091_2023_05_03_0001.hex",
                           path_xmlcon = "C:/CTD/xmlcon config files/SBE19plusV2_8091.xmlcon" )

GAPsurvey::convert_ctd_btd(path_in = "SBE19plus_01908091_2023_05_03_0001.cnv")
